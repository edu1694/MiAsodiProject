export const baseUrl = 'https://djang-api-asodi-production.up.railway.app';
